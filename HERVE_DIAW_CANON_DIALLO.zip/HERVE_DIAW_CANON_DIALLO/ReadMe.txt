Installation :

Utilisateurs Windows
- D�zipper le dossier XXX
- Copier-Coller le contenu du dossier "www" de XXX dans le dossier "\www\" de wamp
- Ouvrir un navigateur et lancer une recherche avec l'url "localhost"

Utilisateurs Linux
- D�zipper le dossier XXX
- Copier-Coller le contenu du dossier "www" de XXX dans le dossier "var/www/"
- Ouvrir un navigateur et lancer une recherche avec l'url "localhost"

Utilisateurs MacOS
- ReadMe non disponible � ce jour

Organisation du dossier "HERVE_DIAW_CANON_DIALLO" :
- le dossier Rapport contient le Rapport au format PDF ainsi que les diff�rentes annexes
- le dossier WEB consiste en un dossier www contenant tous le code de toutes les pages web
- le dossier BDD qui contient le code de d�finition et de contr�le des donn�es :
 	- cr�ation de la base
	- triggers, proc�dures et fonctions
	- les "inserts" permettant de remplir les tables
(les fichiers python qui ont servi � g�n�rer les inserts sont aussi pr�sents)