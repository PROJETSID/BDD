alter table Collection
modify difficulteCol varchar(20);

delete from collection;

INSERT INTO COLLECTION VALUES (1,'Gris',4,'paisible');
INSERT INTO COLLECTION VALUES (2,'Rayures',4,'paisible');
INSERT INTO COLLECTION VALUES (3,'Couleurs',6,'facile');
INSERT INTO COLLECTION VALUES (4,'Formes',6,'facile');
INSERT INTO COLLECTION VALUES (5,'Politiques',6,'mod�r�e');
INSERT INTO COLLECTION VALUES (6,'Plan�tes',6,'mod�r�e');
INSERT INTO COLLECTION VALUES (7,'Psych�d�lique',6,'difficile');
INSERT INTO COLLECTION VALUES (8,'Plan�tes',10,'difficile');
INSERT INTO COLLECTION VALUES (9,'Arbres',10,'cauchemardesque');
INSERT INTO COLLECTION VALUES (10,'Yeux',10,'cauchemardesque');
