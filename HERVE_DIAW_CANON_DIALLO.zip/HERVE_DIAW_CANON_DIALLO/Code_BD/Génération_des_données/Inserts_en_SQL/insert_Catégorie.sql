delete from categorieJoueur;

INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Aluminium','Categorie_joueur\Aluminium.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Fer','Categorie_joueur\Fer.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Carbone','Categorie_joueur\Carbone.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Bronze','Categorie_joueur\Bronze.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Inox','Categorie_joueur\Inox.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Argent','Categorie_joueur\Argent.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Chrome','Categorie_joueur\Chrome.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Or','Categorie_joueur\Or.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Platine','Categorie_joueur\Platine.jpg');
INSERT INTO CATEGORIEJOUEUR VALUES (Seq_CategorieJoueur_idCat.nextval,'Titane','Categorie_joueur\Titane.jpg');
