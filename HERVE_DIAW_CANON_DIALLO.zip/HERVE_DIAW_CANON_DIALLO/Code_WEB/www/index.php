<!DOCTYPE html>

<html>

    <head>

        <meta charset="utf-8" />

        <title>Master Mind</title>
        <link rel="stylesheet" href="style.css" />
		 <?php
		    include("head.php");
		?>

    </head>
    <body>

    <!-- page de début de navigation par défaut -->
    <!-- faire que la page authentification soit la première page par défaut -->


    </body>

</html>








