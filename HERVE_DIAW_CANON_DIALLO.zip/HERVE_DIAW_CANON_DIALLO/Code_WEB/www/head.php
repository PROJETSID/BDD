<!-- menu commun à toutes les pages -->
<div>
	<nav id="mettre_au_milieu_de_la_page">
		<a class="menu_choix_0" href="index.php">Acceuil</a>
 		<a class="menu_choix_1" href="authentification.php">Authentification</a>
		<a class="menu_choix_2" href="typeDePartie.php">Jeu</a>
		<a class="menu_choix_3" href="historique.php">Historique</a>
		<a class="menu_choix_4" href="highScores.php">High Scores</a>
	</nav>
<div>
<div id="logo">
 <img src="images\master.jpg" alt="Logo du jeu" />
</div>
